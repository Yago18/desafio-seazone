from django.db import models

# Create your models here.
class Anuncios(models.Model):
    codigo_do_anuncio = models.IntegerField(primary_key=True)
    codigo_do_imovel = models.IntegerField()
    nome_da_plataforma = models.CharField(max_length=100)
    taxa_da_plataforma = models.FloatField(null=True, blank=True, default=None)
    data_e_hora_de_criacao = models.DateTimeField(auto_now_add=True, blank=True)
    data_e_hora_de_atualizacao = models.DateTimeField(auto_now_add=True, blank=True)

    '''def __str__(self):
        return self.codigo_do_anuncio'''