from django.shortcuts import render

# Create your views here.
from .models import Anuncios
from .forms import AnunciosForm

def anunciosList(request):
    return render(request, 'anuncios/list.html')

def anunciosList(request):
    search = request.GET.get('search')

    if search:
        anuncios = Anuncios.objects.filter(codigo_do_anuncio=search)
    else:
        anuncios = Anuncios.objects.all()#.order_by('-created_at')
    return render(request, 'anuncios/list.html', {'anuncios': anuncios})

def anunciosView(request, id):
    anuncio = get_object_or_404(Anuncios, pk=id)
    return render(request, 'anuncios/anuncios.html', {'anuncios': anuncios})

def novoAnuncio(request):
    if request.method == 'POST':
        form = AnunciosForm(request.POST)
        
        if form.is_valid():
            anuncio = form.save(commit=False)
            anuncio.done = 'doing'
            anuncio.save()
            return redirect('/')
    else:
        form = AnunciosForm
    form = AnunciosForm()
    return render(request, 'anuncios/addAnuncio.html', {'form': form})

def editAnuncio(request, id):
    anuncio = get_object_or_404(Anuncios, pk=id)
    form = AnunciosForm(instance=anuncio)

    if(request.method == 'POST'):
        form = AnunciosForm(request.POST, instance=anuncio)

        if(form.is_valid()):
            anuncio.save()
            return redirect('/')
        else:
            return render(request, 'anuncios/editAnuncio.html', {'form': form, 'anuncio': anuncio})
    else:
        return render(request, 'anuncios/editAnuncio.html', {'form': form, 'anuncio': anuncio})

def deleteAnuncio(request, id):
    anuncio = get_object_or_404(Anuncios, pk=id)
    anuncio.delete()
    return redirect('/')

def idDoAnuncio(request, name):
    return render(request, 'anuncios/anuncios.html', {'name': name})