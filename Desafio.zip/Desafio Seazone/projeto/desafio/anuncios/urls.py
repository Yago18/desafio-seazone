from django.urls import path
from anuncios import views

urlpatterns = [
    #path('admin/', admin.site.urls),
    path('anuncios/', views.anunciosList, name='anuncios-list'),
    path('anuncios/<int:id>', views.anunciosView, name='anuncios-view'),
    path('anuncios/novoAnuncio/', views.novoAnuncio, name="novo-anuncio"),
    path('edit/<int:id>', views.editAnuncio, name="edit-Anuncio"),
    path('delete/<int:id>', views.deleteAnuncio, name="delete-Anuncio"),
    path('idDoAnuncio/<str:name>', views.idDoAnuncio, name='name')
]
