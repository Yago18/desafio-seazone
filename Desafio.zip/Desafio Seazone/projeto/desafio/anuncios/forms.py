from django import forms

from .models import Anuncios

class AnunciosForm(forms.ModelForm):
    class Meta:
        model = Anuncios
        fields = ('codigo_do_anuncio', 'codigo_do_imovel', 'nome_da_plataforma', 'taxa_da_plataforma')