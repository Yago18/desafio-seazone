from django import forms

from .models import Imoveis

class ImoveisForm(forms.ModelForm):
    class Meta:
        model = Imoveis
        fields = ('codigo_do_imovel', 'limite_de_hospedes', 'qtd_de_banheiros', 'aceita_animais_de_estimacao', 'valor_da_limpeza')