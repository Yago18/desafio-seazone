from django.shortcuts import render, get_object_or_404, redirect
from django.http import HttpResponse

from .models import Imoveis
from .forms import ImoveisForm
# Create your views here.

def imoveisList(request):
    search = request.GET.get('search')

    if search:
        imoveis = Imoveis.objects.filter(codigo_do_imovel=search)
    else:
        imoveis = Imoveis.objects.all()#.order_by('-created_at')
    return render(request, 'imoveis/list.html', {'imoveis': imoveis})

def imoveisView(request, id):
    imovel = get_object_or_404(Imoveis, pk=id)
    return render(request, 'imoveis/imoveis.html', {'imovel': imovel})

def novoImovel(request):
    if request.method == 'POST':
        form = ImoveisForm(request.POST)
        
        if form.is_valid():
            imovel = form.save(commit=False)
            imovel.done = 'doing'
            imovel.save()
            return redirect('/')
    else:
        form = ImoveisForm
    form = ImoveisForm()
    return render(request, 'imoveis/addImovel.html', {'form': form})

def editImovel(request, id):
    imovel = get_object_or_404(Imoveis, pk=id)
    form = ImoveisForm(instance=imovel)

    if(request.method == 'POST'):
        form = ImoveisForm(request.POST, instance=imovel)

        if(form.is_valid()):
            imovel.save()
            return redirect('/')
        else:
            return render(request, 'imoveis/editImovel.html', {'form': form, 'imovel': imovel})
    else:
        return render(request, 'imoveis/editImovel.html', {'form': form, 'imovel': imovel})

def deleteImovel(request, id):
    imovel = get_object_or_404(Imoveis, pk=id)
    imovel.delete()
    return redirect('/')

def idDoImovel(request, name):
    return render(request, 'imoveis/imoveis.html', {'name': name})