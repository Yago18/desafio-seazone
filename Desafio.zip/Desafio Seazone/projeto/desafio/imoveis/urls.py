from django.urls import path
from . import views
urlpatterns = [
    #path('admin/', admin.site.urls),
    #path('helloworld/', views.helloWorld),
    path('', views.imoveisList, name='imoveis-list'),
    path('imoveis/<int:id>', views.imoveisView, name='imoveis-view'),
    path('novoImovel/', views.novoImovel, name="novo-imovel"),
    path('edit/<int:id>', views.editImovel, name="edit-Imovel"),
    path('delete/<int:id>', views.deleteImovel, name="delete-Imovel"),
    path('idDoImovel/<str:name>', views.idDoImovel, name='name')
]
