from django.db import models

# Create your models here.

class Imoveis(models.Model):
    codigo_do_imovel = models.IntegerField(primary_key=True)
    limite_de_hospedes = models.IntegerField()
    qtd_de_banheiros = models.IntegerField()
    aceita_animais_de_estimacao = models.BooleanField(default=False)
    valor_da_limpeza = models.FloatField(null=True, blank=True, default=None)
    data_e_hora_de_ativacao = models.DateTimeField(auto_now_add=True, blank=True)
    data_e_hora_de_criacao = models.DateTimeField(auto_now_add=True, blank=True)
    data_e_hora_de_atualizacao = models.DateTimeField(auto_now_add=True, blank=True)

    '''def __str__(self):
        return self.codigo_do_imovel'''