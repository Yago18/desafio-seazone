from django.urls import path
from reservas import views

urlpatterns = [
    #path('admin/', admin.site.urls),
    path('reservas/', views.reservasList, name='reservas-list'),
    path('reservas/<int:id>', views.reservasView, name='reservas-view'),
    path('reservas/novaReserva/', views.novaReserva, name="nova-reserva"),
    path('edit/<int:id>', views.editReserva, name="edit-Reserva"),
    path('delete/<int:id>', views.deleteReserva, name="delete-Reserva")
]
