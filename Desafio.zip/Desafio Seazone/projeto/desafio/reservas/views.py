from django.shortcuts import render

from .models import Reservas
from .forms import ReservasForm
# Create your views here.

def reservasList(request):
    return render(request, 'reservas/list.html')

def reservasList(request):
    search = request.GET.get('search')

    if search:
        reservas = Reservas.objects.filter(codigo_do_anuncio=search)
    else:
        reservas = Reservas.objects.all()#.order_by('-created_at')
    return render(request, 'reservas/list.html', {'reservas': reservas})

def reservasView(request, id):
    reserva = get_object_or_404(Reservas, pk=id)
    return render(request, 'reservas/reservas.html', {'Reservas': reservas})

def novaReserva(request):
    if request.method == 'POST':
        form = ReservasForm(request.POST)
        
        if form.is_valid():
            reserva = form.save(commit=False)
            reserva.done = 'doing'
            reserva.save()
            return redirect('/')
    else:
        form = ReservasForm
    form = ReservasForm()
    return render(request, 'reservas/addReserva.html', {'form': form})

def editReserva(request, id):
    reserva = get_object_or_404(Reservas, pk=id)
    form = ReservasForm(instance=reserva)

    if(request.method == 'POST'):
        form = ReservasForm(request.POST, instance=reserva)

        if(form.is_valid()):
            reserva.save()
            return redirect('/')
        else:
            return render(request, 'reservas/editReserva.html', {'form': form, 'reserva': reserva})
    else:
        return render(request, 'reservas/editReserva.html', {'form': form, 'reserva': reserva})

def deleteReserva(request, id):
    reserva = get_object_or_404(Reservas, pk=id)
    reserva.delete()
    return redirect('/')

def idDaReserva(request, name):
    return render(request, 'reservas/reservas.html', {'name': name})