from django.db import models

# Create your models here.
class Reservas(models.Model):
    codigo_do_imovel = models.IntegerField(primary_key=True)
    data_de_checkin = models.DateField()
    data_de_checkout = models.DateField()
    preco_total = models.FloatField(null=True, blank=True, default=None)
    comentarios = models.TextField(blank=True, null=True)
    numero_de_hospedes = models.IntegerField()
    data_e_hora_de_criacao = models.DateField(auto_now=True)
    data_e_hora_de_atualizacao = models.DateField(auto_now=True)

    '''def __str__(self):
        return self.codigo_do_anuncio'''