from django import forms

from .models import Reservas

class ReservasForm(forms.ModelForm):
    class Meta:
        model = Reservas
        fields = ('codigo_do_imovel', 'data_de_checkin', 'data_de_checkout', 'preco_total', 'comentarios', 'numero_de_hospedes')