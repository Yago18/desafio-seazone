from django.contrib import admin

# Register your models here.
from .models import Reservas

admin.site.register(Reservas)